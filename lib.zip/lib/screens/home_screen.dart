// lib/screens/home_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/location_service.dart';
import '../services/attendance_service.dart';
import '../utils/constants.dart';
import 'attendance_history_screen.dart';
import 'login_screen.dart';
import '../models/attendance_model.dart';
import 'package:geolocator/geolocator.dart';
import 'map_clock_screen.dart'; // <-- import new screen

class HomeScreen extends StatefulWidget {
  static const routeName = '/home';

  final UserModel user;

  const HomeScreen({Key? key, required this.user}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AuthService _authService = AuthService();
  final LocationService _locationService = LocationService();
  final AttendanceService _attendanceService = AttendanceService();
  bool _locationPermissionGranted = false;
  bool _checkingPermission = true;
  String _workingHoursText = '---';
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _checkLocationPermission();
    _calculateWorkingHours();
    _startWorkingHoursTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startWorkingHoursTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateWorkingHoursLive();
    });
  }

  Future<void> _checkLocationPermission() async {
    final granted = await _locationService.requestPermission();
    setState(() {
      _locationPermissionGranted = granted;
      _checkingPermission = false;
    });
  }

  String _formatDurationWithSeconds(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  Future<void> _calculateWorkingHours() async {
    final attendanceList =
    await _attendanceService.getAttendanceHistory(widget.user.employeeId);
    final today = DateTime.now();

    final todayRecord = attendanceList.firstWhere(
          (att) =>
      att.date.year == today.year &&
          att.date.month == today.month &&
          att.date.day == today.day,
      orElse: () => AttendanceModel(date: today),
    );

    if (todayRecord.clockInTime == null) {
      setState(() {
        _workingHoursText = 'Not clocked in';
      });
      return;
    }

    final DateTime startWork = DateTime(
        today.year, today.month, today.day, Constants.workStartHour, Constants.workStartMinute);

    DateTime endTime = todayRecord.clockOutTime ?? DateTime.now();

    final effectiveStart = todayRecord.clockInTime!.isBefore(startWork)
        ? startWork
        : todayRecord.clockInTime!;

    final duration = endTime.difference(effectiveStart);
    setState(() {
      _workingHoursText = _formatDurationWithSeconds(duration.isNegative ? Duration.zero : duration);
    });
  }

  Future<void> _updateWorkingHoursLive() async {
    await _calculateWorkingHours();
  }

  void _navigateToAttendanceHistory() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AttendanceHistoryScreen()),
    );
  }

  Future<void> _handleLogout() async {
    await _authService.logout();
    Navigator.of(context).pushNamedAndRemoveUntil(LoginScreen.routeName, (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text('Hi, ${widget.user.name} 👋'),
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _navigateToAttendanceHistory,
            icon: const Icon(Icons.history),
            tooltip: 'View History',
          ),
          IconButton(
            onPressed: _handleLogout,
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
          ),
        ],
      ),
      body: _checkingPermission
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 3,
              child: ListTile(
                contentPadding: const EdgeInsets.all(20),
                leading: const Icon(Icons.access_time, size: 36, color: Colors.blue),
                title: const Text('Working Hours Today',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    _workingHoursText,
                    style: const TextStyle(fontSize: 22, color: Colors.black87),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40),
            // Always show clock in/out buttons here
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => MapClockScreen(
                    employeeId: widget.user.employeeId,
                    isClockIn: true,
                    onSuccess: _calculateWorkingHours,
                  ),
                ));
              },
              child: const Text('Clock In'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => MapClockScreen(
                    employeeId: widget.user.employeeId,
                    isClockIn: false,
                    onSuccess: _calculateWorkingHours,
                  ),
                ));
              },
              child: const Text('Clock Out'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
