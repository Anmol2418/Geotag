// lib/screens/map_clock_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

import '../services/location_service.dart';
import '../services/attendance_service.dart';
import '../utils/constants.dart';
import '../utils/geofence_utils.dart';

class MapClockScreen extends StatefulWidget {
  final String employeeId;
  final bool isClockIn;
  final VoidCallback onSuccess;

  const MapClockScreen({
    Key? key,
    required this.employeeId,
    required this.isClockIn,
    required this.onSuccess,
  }) : super(key: key);

  @override
  State<MapClockScreen> createState() => _MapClockScreenState();
}

class _MapClockScreenState extends State<MapClockScreen> {
  final _location = LocationService();
  final _attendance = AttendanceService();

  late final MapController _mapController;
  bool _mapReady = false;
  LatLng? _pendingCenter;

  Position? _pos;
  bool _inside = false;
  bool _busy = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _getAndCheckLocation();
  }

  // ───────────────────────── helpers ─────────────────────────
  Future<void> _getAndCheckLocation() async {
    setState(() {
      _busy = true;
      _err = null;
    });

    try {
      final ok = await _location.requestPermission();
      if (!ok) throw 'Location permission denied';

      final p = await _location.getCurrentPosition();
      final inside = await GeofenceUtils.isWithinGeofence(p);

      setState(() {
        _pos = p;
        _inside = inside;
        _busy = false;
      });

      // decide where to center
      _pendingCenter = inside
          ? LatLng(p.latitude, p.longitude)
          : LatLng(Constants.geofenceLatitude, Constants.geofenceLongitude);

      if (_mapReady && _pendingCenter != null) {
        _mapController.move(_pendingCenter!, inside ? 17 : 15);
        _pendingCenter = null;
      }
    } catch (e) {
      setState(() {
        _err = e.toString();
        _busy = false;
      });
    }
  }

  Future<void> _clock() async {
    if (!_inside || _pos == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('You must be inside the geofence.'),
      ));
      return;
    }
    setState(() => _busy = true);

    try {
      final now = DateTime.now();
      if (widget.isClockIn) {
        await _attendance.clockIn(widget.employeeId, now);
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Clock‑In successful')));
      } else {
        await _attendance.clockOut(widget.employeeId, now);
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Clock‑Out successful')));
      }
      widget.onSuccess();
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ───────────────────────── UI ─────────────────────────
  @override
  Widget build(BuildContext context) {
    final office = LatLng(Constants.geofenceLatitude, Constants.geofenceLongitude);

    return Scaffold(
      appBar: AppBar(title: Text(widget.isClockIn ? 'Clock In' : 'Clock Out')),
      body: _busy && _pos == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: office,
                initialZoom: 15,
                onMapReady: () {
                  _mapReady = true;
                  if (_pendingCenter != null) {
                    _mapController.move(_pendingCenter!, _inside ? 17 : 15);
                    _pendingCenter = null;
                  }
                },
              ),
              children: [
                TileLayer(
                  urlTemplate:
                  'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.app',
                ),
                // geofence circle
                CircleLayer(circles: [
                  CircleMarker(
                    point: office,
                    radius: Constants.geofenceRadius,   // meters
                    useRadiusInMeter: true,
                    color: Colors.blue.withOpacity(0.15),
                    borderStrokeWidth: 2,
                    borderColor: Colors.blue,
                  ),
                ]),
                if (_pos != null)
                  MarkerLayer(
                    markers: [
                      Marker(
                        width: 40,
                        height: 40,
                        point: LatLng(_pos!.latitude, _pos!.longitude),
                        child: const Icon(
                          Icons.person_pin_circle,
                          color: Colors.red,
                          size: 40,
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(_err!, style: const TextStyle(color: Colors.red)),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _clock,
              icon: _busy
                  ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white),
              )
                  : Icon(widget.isClockIn ? Icons.login : Icons.logout),
              label: Text(widget.isClockIn ? 'Clock In' : 'Clock Out'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        heroTag: 'refreshPos',
        onPressed: _getAndCheckLocation,
        child: const Icon(Icons.my_location),
      ),
    );
  }
}
