import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/attendance_service.dart';
import '../models/attendance_model.dart';
import 'package:intl/intl.dart';

class AttendanceHistoryScreen extends StatefulWidget {
  static const routeName = '/attendance-history';

  const AttendanceHistoryScreen({Key? key}) : super(key: key);

  @override
  State<AttendanceHistoryScreen> createState() => _AttendanceHistoryScreenState();
}

class _AttendanceHistoryScreenState extends State<AttendanceHistoryScreen> {
  final AuthService _authService = AuthService();
  final AttendanceService _attendanceService = AttendanceService();

  List<AttendanceModel> _attendanceList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAttendanceHistory();
  }

  Future<void> _loadAttendanceHistory() async {
    try {
      final user = await _authService.getCurrentUser();
      if (user == null) {
        Navigator.of(context).pop();
        return;
      }
      final attendance = await _attendanceService.getAttendanceHistory(user.employeeId);
      setState(() {
        _attendanceList = attendance;
        _isLoading = false;
      });
    } catch (e) {
      _showError('Failed to load attendance history: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showError(String message) {
    final snackBar = SnackBar(content: Text(message), backgroundColor: Colors.redAccent);
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  String _formatDuration(Duration? duration) {
    if (duration == null) return '-';
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '${hours}h ${minutes}m';
  }

  Widget _buildAttendanceCard(AttendanceModel attendance) {
    final dateFormatted = DateFormat.yMMMMEEEEd().format(attendance.date);
    final clockInStr = attendance.clockInTime != null
        ? DateFormat.Hm().format(attendance.clockInTime!)
        : '-';
    final clockOutStr = attendance.clockOutTime != null
        ? DateFormat.Hm().format(attendance.clockOutTime!)
        : '-';
    final durationStr = _formatDuration(attendance.duration);

    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        title: Text(
          dateFormatted,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.login, size: 18, color: Colors.green),
                const SizedBox(width: 4),
                Text('In: $clockInStr'),
                const SizedBox(width: 16),
                const Icon(Icons.logout, size: 18, color: Colors.redAccent),
                const SizedBox(width: 4),
                Text('Out: $clockOutStr'),
              ],
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.timer, color: Colors.blue),
            const SizedBox(height: 4),
            Text(durationStr),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance History'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _attendanceList.isEmpty
          ? const Center(
        child: Text(
          'No attendance records found.',
          style: TextStyle(fontSize: 18),
        ),
      )
          : ListView.builder(
        itemCount: _attendanceList.length,
        itemBuilder: (context, index) {
          return _buildAttendanceCard(_attendanceList[index]);
        },
      ),
    );
  }
}
