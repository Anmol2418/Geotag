// lib/models/attendance_model.dart
class AttendanceModel {
  final String? id;           // Record ID from the database
  final DateTime date;        // Attendance date (without time)
  final DateTime? clockInTime;
  final DateTime? clockOutTime;
  final Duration? duration;   // Duration worked, nullable

  AttendanceModel({
    this.id,
    required this.date,
    this.clockInTime,
    this.clockOutTime,
    this.duration,
  });

  factory AttendanceModel.fromMap(Map<String, dynamic> map) {
    final DateTime date = DateTime.parse(map['date']);
    final DateTime? clockInTime =
    map['clock_in_time'] != null ? DateTime.parse(map['clock_in_time']) : null;
    final DateTime? clockOutTime =
    map['clock_out_time'] != null ? DateTime.parse(map['clock_out_time']) : null;

    Duration? duration;
    if (map['duration'] != null) {
      duration = Duration(seconds: map['duration']);
    } else if (clockInTime != null && clockOutTime != null) {
      duration = clockOutTime.difference(clockInTime);
    }

    return AttendanceModel(
      id: map['id'] as String?,
      date: date,
      clockInTime: clockInTime,
      clockOutTime: clockOutTime,
      duration: duration,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'date': date.toIso8601String(),
      'clock_in_time': clockInTime?.toIso8601String(),
      'clock_out_time': clockOutTime?.toIso8601String(),
      'duration': duration?.inSeconds,
    };
  }
}
