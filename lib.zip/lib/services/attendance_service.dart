import 'package:supabase_flutter/supabase_flutter.dart';
import '../supabase_client.dart';
import '../models/attendance_model.dart';
import '../utils/constants.dart';

class AttendanceService {
  final SupabaseClient _client = SupabaseClientInstance.client;

  /// Clock in user for [employeeId]
  /// Returns the inserted or updated AttendanceModel for today.
  Future<AttendanceModel> clockIn(String employeeId, DateTime actualClockInTime) async {
    final DateTime today = DateTime(
      actualClockInTime.year,
      actualClockInTime.month,
      actualClockInTime.day,
    );

    final DateTime nineThirty = DateTime(
      today.year, today.month, today.day,
      Constants.workStartHour, Constants.workStartMinute,
    );

    // 👇 Use actual time if clock-in is after 9:30, else store as-is but count from 9:30
    final DateTime storedClockInTime = actualClockInTime;

    try {
      // Check if record exists
      final existing = await _client
          .from('attendance')
          .select()
          .eq('employee_id', employeeId)
          .eq('date', today.toIso8601String().split('T')[0])
          .maybeSingle();

      if (existing != null && existing['clock_in_time'] != null) {
        throw Exception('Already clocked in today.');
      }

      if (existing != null) {
        // Update existing record
        final updated = await _client
            .from('attendance')
            .update({
          'clock_in_time': storedClockInTime.toIso8601String(),
        })
            .eq('id', existing['id'])
            .select()
            .single();

        return AttendanceModel.fromMap(updated);
      }

      // Insert new record
      final inserted = await _client.from('attendance').insert({
        'employee_id': employeeId,
        'date': today.toIso8601String().split('T')[0],
        'clock_in_time': storedClockInTime.toIso8601String(),
        'clock_out_time': null,
        'duration': null,
      }).select().single();

      return AttendanceModel.fromMap(inserted);
    } catch (e) {
      throw Exception('Clock-in failed: $e');
    }
  }


  /// Clock out user and calculate working duration
  Future<AttendanceModel> clockOut(String employeeId, DateTime actualClockOutTime) async {
    final DateTime today = DateTime(
      actualClockOutTime.year,
      actualClockOutTime.month,
      actualClockOutTime.day,
    );

    final DateTime workStartTime = DateTime(
      today.year, today.month, today.day,
      Constants.workStartHour, Constants.workStartMinute,
    );

    try {
      final record = await _client
          .from('attendance')
          .select()
          .eq('employee_id', employeeId)
          .eq('date', today.toIso8601String().split('T')[0])
          .maybeSingle();

      if (record == null) {
        throw Exception('No clock-in record found for today.');
      }

      if (record['clock_in_time'] == null) {
        throw Exception('Must clock in before clocking out.');
      }

      if (record['clock_out_time'] != null) {
        throw Exception('Already clocked out today.');
      }

      final DateTime clockInTime = DateTime.parse(record['clock_in_time']);
      final DateTime clockOutTime = actualClockOutTime.isBefore(clockInTime)
          ? clockInTime
          : actualClockOutTime;

      final DateTime effectiveStart = workStartTime.isAfter(clockInTime)
          ? workStartTime
          : clockInTime;

      final Duration duration = clockOutTime.difference(effectiveStart);
      final int durationInSeconds = duration.inSeconds > 0 ? duration.inSeconds : 0;

      final updated = await _client
          .from('attendance')
          .update({
        'clock_out_time': clockOutTime.toIso8601String(),
        'duration': durationInSeconds,
      })
          .eq('id', record['id'])
          .select()
          .single();

      return AttendanceModel.fromMap(updated);
    } catch (e) {
      throw Exception('Clock-out failed: $e');
    }
  }

  /// Get all attendance records (latest first)
  Future<List<AttendanceModel>> getAttendanceHistory(String employeeId) async {
    try {
      final data = await _client
          .from('attendance')
          .select()
          .eq('employee_id', employeeId)
          .order('date', ascending: false);

      return (data as List<dynamic>)
          .map((e) => AttendanceModel.fromMap(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch attendance history: $e');
    }
  }
}
