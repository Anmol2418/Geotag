// lib/services/storage_service.dart
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _keyEmployeeId = 'employee_id';
  static const String _keyPassword = 'password';
  static const String _keyRememberMe = 'remember_me';

  static Future<void> saveCredentials({
    required String employeeId,
    required String password,
  }) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyEmployeeId, employeeId);
    await prefs.setString(_keyPassword, password);
    await prefs.setBool(_keyRememberMe, true);
  }

  static Future<Map<String, dynamic>?> getSavedCredentials() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final bool? rememberMe = prefs.getBool(_keyRememberMe);
    if (rememberMe == true) {
      final String? employeeId = prefs.getString(_keyEmployeeId);
      final String? password = prefs.getString(_keyPassword);
      if (employeeId != null && password != null) {
        return {
          'employeeId': employeeId,
          'password': password,
        };
      }
    }
    return null;
  }

  static Future<void> clearCredentials() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyEmployeeId);
    await prefs.remove(_keyPassword);
    await prefs.setBool(_keyRememberMe, false);
  }
  static Future<Map<String, dynamic>> getCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    final empId = prefs.getString('employeeId');
    final password = prefs.getString('password');
    return {
      'employeeId': empId,
      'password': password,
    };
  }
}