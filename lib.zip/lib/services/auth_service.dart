import 'package:supabase_flutter/supabase_flutter.dart';
import '../supabase_client.dart';
import '../models/user_model.dart';
import 'storage_service.dart';

class AuthService {
  final SupabaseClient _client = SupabaseClientInstance.client;

  /// Get current user — unused but kept for possible future use
  Future<UserModel?> getCurrentUser() async {
    final user = _client.auth.currentUser;
    if (user == null) return null;

    return UserModel(
      employeeId: user.id,
      name: user.userMetadata?['name'] ?? 'Unknown',
    );
  }

  /// Manual login using employee_id and password from `employees` table
  Future<UserModel?> login({
    required String employeeId,
    required String password,
    required bool rememberMe,
  }) async {
    try {
      final response = await _client
          .from('employees')
          .select()
          .eq('employee_id', employeeId)
          .eq('password', password.trim()) // Ideally hash comparison
          .maybeSingle();

      if (response != null && response is Map<String, dynamic>) {
        final user = UserModel(
          employeeId: response['employee_id'] as String,
          name: response['name'] as String? ?? 'Unknown',
        );

        if (rememberMe) {
          await StorageService.saveCredentials(
            employeeId: employeeId,
            password: password,
          );
        } else {
          await StorageService.clearCredentials();
        }

        return user;
      }

      return null;
    } catch (e) {
      print('Login failed: $e');
      return null;
    }
  }
  Future<bool> register({
    required String employeeId,
    required String email,
    required String name,
    required String password,
  }) async {
    try {
      final response = await _client.from('employees').insert({
        'employee_id': employeeId.trim(),
        'email': email.trim(),
        'name': name.trim(),
        'password': password.trim(),
      });

      print('✅ Raw Supabase insert response: $response');

      // If response is a list and not empty, it's successful
      if (response != null && response is List && response.isNotEmpty) {
        return true;
      }

      print('❌ Insert failed — response empty or null');
      return false;
    } on PostgrestException catch (e) {
      print('🔥 Supabase PostgrestException: ${e.message}');
      return false;
    } catch (e, st) {
      print('❗ Unknown error: $e');
      print('📌 Stacktrace: $st');
      return false;
    }
  }





  /// Auto-login if credentials are stored
  Future<UserModel?> getRememberedUser() async {
    final creds = await StorageService.getCredentials();
    if (creds == null) return null;

    return await login(
      employeeId: creds['employeeId']!,
      password: creds['password']!,
      rememberMe: true,
    );
  }

  /// Logout and clear stored credentials
  Future<void> logout() async {
    await StorageService.clearCredentials();
  }
}
